import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController ageController = TextEditingController();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Flutter CRUD App'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Container(
                width: 300,
                child: TextField(
                  controller: nameController,
                  decoration: InputDecoration(hintText: 'Enter Name'),
                ),
              ),
              SizedBox(height: 20),
              Container(
                width: 300,
                child: TextField(
                  controller: ageController,
                  decoration: InputDecoration(hintText: 'Enter Age'),
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () async {
                  await _firestore.collection('users').add({
                    'name': nameController.text,
                    'age': ageController.text,
                  });
                  nameController.clear();
                  ageController.clear();
                },
                child: Text('Add User'),
              ),
              SizedBox(height: 20),
              StreamBuilder<QuerySnapshot>(
                stream: _firestore.collection('users').snapshots(),
                builder: (BuildContext context,
                    AsyncSnapshot<QuerySnapshot> snapshot) {
                  if (snapshot.hasError) {
                    return Text('Error: ${snapshot.error}');
                  }
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return CircularProgressIndicator();
                  }
                  return Expanded(
                    child: ListView(
                      children:
                          snapshot.data!.docs.map((DocumentSnapshot document) {
                        return ListTile(
                          title: Text((document.data()
                                  as Map<String, dynamic>)['name'] ??
                              ''),
                          subtitle: Text((document.data()
                                  as Map<String, dynamic>)['age'] ??
                              ''),
                          trailing: IconButton(
                            icon: Icon(Icons.delete),
                            onPressed: () async {
                              await _firestore
                                  .collection('users')
                                  .doc(document.id)
                                  .delete();
                            },
                          ),
                        );
                      }).toList(),
                    ),
                  );
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () async {
                  QuerySnapshot querySnapshot = await _firestore
                      .collection('users')
                      .where('name', isEqualTo: 'John Doe')
                      .get();

                  querySnapshot.docs.forEach((doc) {
                    print(doc.data());
                  });
                },
                child: Text('Get User'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
